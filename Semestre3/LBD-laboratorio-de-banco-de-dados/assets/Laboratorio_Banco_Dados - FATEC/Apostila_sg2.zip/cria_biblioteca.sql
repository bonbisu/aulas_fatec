-- Script Criacao e Populacao de tabelas - Biblioteca
/* parametros de configuracao da sessao */
ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MM-YYYY HH24:MI:SS';
ALTER SESSION SET NLS_LANGUAGE = 'PORTUGUESE' ;
SELECT SESSIONTIMEZONE, CURRENT_TIMESTAMP FROM DUAL;

-- excluindo as tabelas
DROP TABLE Aluno CASCADE CONSTRAINTS PURGE;
DROP TABLE Curso CASCADE CONSTRAINTS PURGE;
DROP TABLE Funcionario CASCADE CONSTRAINTS PURGE;
DROP TABLE Obra CASCADE CONSTRAINTS PURGE;
DROP TABLE Reserva CASCADE CONSTRAINTS PURGE;
DROP TABLE Professor CASCADE CONSTRAINTS PURGE;
DROP TABLE Usuario CASCADE CONSTRAINTS PURGE;
DROP TABLE Exemplar CASCADE CONSTRAINTS PURGE;
DROP TABLE Editora CASCADE CONSTRAINTS PURGE;
DROP TABLE Emprestimo CASCADE CONSTRAINTS PURGE;
DROP TABLE Participacao_obra CASCADE CONSTRAINTS PURGE;
DROP TABLE Participantes_obra CASCADE CONSTRAINTS PURGE;
DROP TABLE Itens_Emprestimo CASCADE CONSTRAINTS PURGE;
DROP TABLE Itens_reserva CASCADE CONSTRAINTS PURGE;
DROP TABLE Autor CASCADE CONSTRAINTS PURGE;
DROP TABLE Idioma CASCADE CONSTRAINTS PURGE;
DROP TABLE Nacionalidade CASCADE CONSTRAINTS PURGE;
DROP TABLE ItemEmprestimo CASCADE CONSTRAINTS PURGE;

-- tabela usuario
CREATE TABLE Usuario
(	Cod_usuario          INTEGER NOT NULL ,
	Nome_usuario         VARCHAR2(75) NOT NULL ,
	End_usuario          VARCHAR2(100) NOT NULL ,
	Fone_usuario         NUMBER(14) NOT NULL ,
	Sexo_usuario         CHAR(1) NOT NULL ,
	Dt_nascto_usuario    DATE NOT NULL ,
	CPF_usuario          NUMBER(14) NOT NULL ,
	RG_usuario           CHAR(10) NOT NULL ,
	email_usuario        CHAR(32) NOT NULL ,
	Situacao_usuario     CHAR(15) NOT NULL ,
CONSTRAINT  PKUsuario PRIMARY KEY (Cod_usuario));

-- tabela professor
CREATE TABLE Professor
(	Cod_prof          INTEGER NOT NULL ,
	Cod_funcional        INTEGER NOT NULL ,
	Titulacao            CHAR(15) NOT NULL ,
	Dt_admissao          DATE NOT NULL ,
	Dt_desligamento      DATE ,
CONSTRAINT  PKProfessor PRIMARY KEY (Cod_prof),
CONSTRAINT UQprof UNIQUE ( cod_funcional),
CONSTRAINT FKprof_usu FOREIGN KEY (Cod_prof) REFERENCES Usuario (Cod_usuario) ON DELETE CASCADE);


-- obra
CREATE TABLE Obra
(	ISBN                 NUMBER(13) NOT NULL ,
	Titulo_original      CHAR(75) NOT NULL ,
	Idioma_original      CHAR(15) NOT NULL ,
	Genero               CHAR(25) NOT NULL ,
	Classificacao        CHAR(25) NOT NULL ,
CONSTRAINT  PKObra PRIMARY KEY (ISBN));

-- editora
CREATE TABLE Editora
(	Cod_editora          SMALLINT NOT NULL ,
	Nome_edit            VARCHAR2(48) NOT NULL ,
	End_edit             VARCHAR2(48) NOT NULL ,
	Fone_edit            NUMBER(13) NOT NULL ,
	CNPJ_edit            NUMBER(14) NOT NULL UNIQUE ,
	contato_edit         VARCHAR2(38) NOT NULL ,
	Nacionalidade_edit   CHAR(20) NOT NULL ,
CONSTRAINT  PKEditora PRIMARY KEY (Cod_editora));


-- exemplar
CREATE TABLE Exemplar
(	Num_exemplar         SMALLINT NOT NULL ,
	ISBN                 NUMBER(13) NOT NULL ,
	Num_edicao           SMALLINT NOT NULL ,
	Idioma_exemplar      CHAR(15) NOT NULL ,
	Ano_publicacao       SMALLINT NOT NULL ,
	Qtde_pags            SMALLINT NOT NULL ,
	Tipo_exemplar        CHAR(15) NOT NULL ,
	Tipo_midia           CHAR(15) NOT NULL ,
	Vl_exemplar          NUMBER(8,2) NOT NULL ,
	Prazo_devolucao      SMALLINT NOT NULL ,
	Tipo_aquisicao       CHAR(15) NOT NULL ,
	Situacao_exemplar    CHAR(15) NOT NULL ,
	Cod_editora          SMALLINT NOT NULL ,
CONSTRAINT  PKExemplar PRIMARY KEY (Num_exemplar,ISBN),
CONSTRAINT FKexemp_obra FOREIGN KEY (ISBN) REFERENCES Obra (ISBN) ON DELETE CASCADE,
CONSTRAINT FKexemp_edit FOREIGN KEY (Cod_editora) REFERENCES Editora (Cod_editora));



-- emprestimo
CREATE TABLE Emprestimo
(	Num_emprestimo       INTEGER NOT NULL ,
	Dt_retirada          TIMESTAMP NOT NULL ,
	Vl_total_multa       NUMBER(8,2) NOT NULL ,
	Situacao_emprest     CHAR(15) NOT NULL ,
	Cod_usuario          INTEGER NOT NULL REFERENCES Usuario (Cod_usuario),
CONSTRAINT  PKEmprestimo PRIMARY KEY (Num_emprestimo));


-- itens emprestimo
CREATE TABLE Itens_Emprestimo
(	Num_emprestimo       INTEGER NOT NULL ,
	Num_exemplar         SMALLINT NOT NULL ,
	ISBN                 NUMBER(13) NOT NULL ,
	Dt_Prevista_Devolucao TIMESTAMP NOT NULL ,
	Dt_Devolucao         TIMESTAMP ,
	Vl_multa_item        NUMBER(8,2) ,
	Situacao_item_emprest CHAR(15) NOT NULL ,
CONSTRAINT  PKItens_Emprestimo PRIMARY KEY (Num_emprestimo,Num_exemplar,ISBN),
CONSTRAINT FKiemp_emp FOREIGN KEY (Num_emprestimo) REFERENCES Emprestimo (Num_emprestimo) ON DELETE CASCADE,
CONSTRAINT FKiemp_exemp FOREIGN KEY (Num_exemplar, ISBN) REFERENCES Exemplar (Num_exemplar, ISBN) ON DELETE CASCADE);


-- Alteracao na estrutura das tabelas
-- Adicionando nova coluna
ALTER TABLE usuario ADD tipo_usuario CHAR(12) ;
-- Adicionando uma constraint de verificacao
ALTER TABLE usuario ADD CHECK ( tipo_usuario IN ( 'ALUNO', 'PROFESSOR', 'FUNCIONARIO'));
-- Alterando para coluna not null
ALTER TABLE usuario MODIFY tipo_usuario NOT NULL ;
-- mudando o tamanho ou tipo de dado
ALTER TABLE obra MODIFY genero VARCHAR2(25);
-- renomeando uma coluna
ALTER TABLE exemplar RENAME COLUMN qtde_pags TO numero_paginas ;

-- definindo um valor padrao
ALTER TABLE itens_emprestimo MODIFY vl_multa_item DEFAULT 0.0 ;
ALTER TABLE emprestimo MODIFY dt_retirada DEFAULT current_timestamp ;

-- definindo chaves
-- chave unica
ALTER TABLE usuario ADD UNIQUE ( cpf_usuario) ;

-- adicionando os CHECKs
ALTER TABLE emprestimo ADD CHECK ( situacao_emprest IN ( 'CONCLUIDO', 'PENDENTE', 'CANCELADO'));
ALTER TABLE reserva ADD CHECK ( situacao_reserva IN ( 'CONCLUIDO', 'PENDENTE', 'CANCELADO'));

ALTER TABLE itens_emprestimo ADD CHECK ( situacao_item_emprest IN ( 'DEVOLVIDO', 'PENDENTE', 'DANIFICADO', 'PERDA'));
ALTER TABLE itens_reserva ADD CHECK ( situacao_item_reserva IN ( 'PENDENTE', 'EMPRESTIMO', 'SEM EMPRESTIMO'));

-- definindo sequencias
DROP SEQUENCE emprestimo_seq ;
CREATE SEQUENCE emprestimo_seq START WITH 16000 ;

DROP SEQUENCE reserva_seq ;
CREATE SEQUENCE reserva_seq START WITH 600 ;

/*****
Atividade 01 :

1- Montar o script em SQL para a cria��o das tabelas EM AMARELO (Aluno, Funcion�rio, Curso, Reserva, Itens da Reserva, Autor e Participa��o na Obra) no SGBD Oracle , com as seguintes caracter�sticas : 
a) Considere as seguintes auto-numera��es :
	N�mero de Reserva come�ando em 600.
b) A��es referenciais ON DELETE.
c) Colunas que indicam instante de tempo com o tipo de dado correspondente (DATE ou TIMESTAMP).*/

-- funcionario
CREATE TABLE Funcionario
(	Cod_func             INTEGER NOT NULL ,
	Cod_funcional        INTEGER NOT NULL ,
	Cargo                VARCHAR2(20) NOT NULL ,
	Dt_admissao          DATE NOT NULL ,
	Dt_desligamento      DATE ,
CONSTRAINT  PKFuncionario PRIMARY KEY (Cod_func),
CONSTRAINT UQfunc UNIQUE ( cod_funcional),
CONSTRAINT FKfunc_usu FOREIGN KEY (Cod_func) REFERENCES Usuario (Cod_usuario) ON DELETE CASCADE );

-- aluno
CREATE TABLE Aluno
(	Cod_aluno          INTEGER NOT NULL ,
	RA                   INTEGER NOT NULL ,
	Dt_ingresso          DATE NOT NULL ,
	Dt_prevista_termino  DATE NOT NULL ,
	Cod_curso            SMALLINT NOT NULL ,
CONSTRAINT  PKAluno PRIMARY KEY (Cod_aluno),
CONSTRAINT UQaluno UNIQUE ( RA),
CONSTRAINT FKalu_usu FOREIGN KEY (Cod_aluno) REFERENCES Usuario (Cod_usuario) ON DELETE CASCADE );

-- curso
CREATE TABLE Curso
(	Cod_curso            SMALLINT NOT NULL ,
	Nome_curso           VARCHAR2(50) NOT NULL ,
	Tipo_curso           CHAR(15) NOT NULL ,
CONSTRAINT  PKCurso PRIMARY KEY (Cod_curso));

-- reserva
CREATE TABLE Reserva
(	Num_reserva          SMALLINT PRIMARY KEY ,
	Dt_reserva           DATE NOT NULL ,
	Dt_limite            DATE NOT NULL ,
	Situacao_reserva     CHAR(15) NOT NULL ,
	Cod_prof          INTEGER NOT NULL ,
CONSTRAINT FKres_prof FOREIGN KEY (Cod_prof) REFERENCES Professor (Cod_prof));

-- itens reserva
CREATE TABLE itens_reserva
(	Num_reserva          SMALLINT NOT NULL REFERENCES Reserva (Num_reserva) ON DELETE CASCADE,
	ISBN                 NUMBER(13) NOT NULL REFERENCES Obra (ISBN) ON DELETE CASCADE ,
	Situacao_item_reserva CHAR(15) NOT NULL ,
CONSTRAINT  PKReserva_Obra PRIMARY KEY (Num_reserva,ISBN));

-- autor
CREATE TABLE Autor
(	Cod_autor            SMALLINT NOT NULL ,
	Nome_autor           CHAR(75) NOT NULL ,
	Nacionalidade_autor  CHAR(20) NOT NULL ,
CONSTRAINT  PKAutor PRIMARY KEY (Cod_autor));

-- participacao obra
CREATE TABLE Participacao_obra
(	ISBN                 NUMBER(13) NOT NULL REFERENCES Obra (ISBN) ON DELETE CASCADE,
	Cod_autor            SMALLINT NOT NULL REFERENCES Autor (Cod_autor) ON DELETE CASCADE,
	Tipo_participacao    CHAR(18) NOT NULL ,
CONSTRAINT  PKParticipacao_obra PRIMARY KEY (ISBN,Cod_autor));

/* 2- Com o comando ALTER TABLE : 
a) Inclua  uma nova coluna em Obra : Palavras_chave para facilitar a busca n�o s� pelo G�nero */
ALTER TABLE obra ADD palavra_chave VARCHAR2(30) ;

/* b) Crie as seguintes constraints de verifica��o : 
		Tipo de participa��o : Principal, Co-autor, Revisor e Tradutor
		Tipo do curso : Tecnologia, Bacharelado e Licenciatura */

desc participantes_obra ;
ALTER TABLE participacao_obra RENAME TO participantes_obra ;

ALTER TABLE participantes_obra ADD CHECK ( tipo_participacao IN 
( 'PRINCIPAL', 'CO-AUTOR', 'REVISOR', 'TRADUTOR'));
desc curso ;
ALTER TABLE curso ADD CHECK (tipo_curso IN ( 'TECNOLOGIA', 'BACHARELADO', 'LICENCIATURA'));
    
--c) Renomeie alguma coluna;
descr itens_emprestimo; 
ALTER TABLE itens_emprestimo RENAME COLUMN situacao_item_emprest TO situacao_itens_emprestimo ;

--d) Renomeie a tabela Participacao_obra para Participantes_obra ;
-- renomeando uma tabela
-- ALTER TABLE participacao_obra RENAME TO participantes_obra ;

--e) Altere o tipo de dados de alguma coluna CHAR para VARCHAR;
ALTER TABLE curso MODIFY tipo_curso VARCHAR2(15) ;

--f) Coloque valores default para todas as colunas que indiquem Valor e para a data da reserva.
desc reserva ;
ALTER TABLE reserva MODIFY dt_reserva DEFAULT current_date ;
ALTER TABLE reserva MODIFY dt_limite DEFAULT current_date + 7 ;

/***********************
Popula��o das tabelas
************************/
--usuario
desc usuario;
INSERT INTO usuario VALUES ( 1, 'Jose de Arimateia', 'Rua A, 10', 551198765432, 'M', '10/10/1980', 123456, '98765X',
'zearimateia@gmail.com', 'ATIVO', 'PROFESSOR') ;
INSERT INTO usuario VALUES ( 2, 'Maria Auxiliadora de Souza', 'Rua B, 10', 5511818158484, 'F', '20/11/1983', 123999, '87655X',
'auxilidadorams@gmail.com', 'ATIVO', 'FUNCIONARIO') ;
INSERT INTO usuario VALUES ( 3, 'Rui Rei Dos Santos', 'Rua C, 30', 5511345358777, 'M', '11/08/1993', 654999, '82325X',
'rrsantos@gmail.com', 'ATIVO', 'ALUNO') ;
INSERT INTO usuario VALUES ( 4, 'Carla Fitzgerald', 'Rua D, 40', 5511452158773, 'F', '21/01/1996', 654543, '987532',
'carlafitz@gmail.com', 'ATIVO', 'ALUNO') ;
INSERT INTO usuario VALUES ( 5, 'Tereza Soares', 'Rua W, 10', 551167565431, 'F', '10/01/1970', 452456, '98213X',
'terezaso@gmail.com', 'ATIVO', 'PROFESSOR') ;
INSERT INTO usuario VALUES ( 6, 'Mariana Volfenburg', 'Rua J, 20', 5511387668777, 'F', '11/08/1991', 621399, '87885X',
'mburg@gmail.com', 'ATIVO', 'ALUNO') ;
INSERT INTO usuario VALUES ( 7, 'Tancredo Seles', 'Rua D, 45', 5511999158773, 'M', '21/01/1988', 654587, '983432',
'tanseles@hotmail.com', 'ATIVO', 'ALUNO') ;

SELECT * FROM Usuario ;

--obra
desc obra;
INSERT INTO obra VALUES (9788580555332, 'Engenharia de Software', 'Ingles', 'Computacao', 'Livro Tecnico', 'desenvolvimento software');
INSERT INTO obra VALUES (9788576052371, 'Sistemas Operacionais Modernos', 'Ingles', 'Computacao', 'Livro Tecnico', 'sistema operacional' );

SELECT * FROM Obra ;

-- editora
desc editora;
SELECT * FROM editora ;
INSERT INTO editora VALUES
(1, 'Makron Books', 'Tabapua , 1348-Itaim-Bibi', 551165657878, 1234567890, 'Chico@uol.com.br', 'Estados Unidos');
INSERT INTO editora VALUES
(2, 'Pearson', 'Orqu�deas, 1548 - Cidade Universitaria', 551138498784, 6543213467, 'vendas@hotmail.com', 'Estados Unidos');
DELETE FROM editora WHERE cod_editora = 3 ;
INSERT INTO editora VALUES
(3, 'Globo', 'Barata Ribeiro, 356-Copacabana', 552122229876, 231765899, 'globo@globo.com.br', 'Brasil');


-- exemplar 
desc exemplar ;
ALTER TABLE exemplar DROP COLUMN cod_idioma_exemplar ;
DELETE FROM exemplar ;

-- depois de alterado o idioma e titulo exemplar
ALTER TABLE exemplar ADD titulo_exemplar VARCHAR2(50) ;
ALTER TABLE exemplar MODIFY titulo_exemplar VARCHAR2(100) ;
INSERT INTO exemplar VALUES ( 1, 9788580555332, 9, 'Portugues', 2014, 786, 'CIRCULANTE',
'Brochura', 219.65, 7, 'COMPRA', 'ATIVO', 1, 'Engenharia de Software') ;
INSERT INTO exemplar VALUES ( 1,9788576052371, 3, 'Portugues', 2011, 316, 'CIRCULANTE',
'Brochura', 109.65, 7, 'COMPRA', 'ATIVO', 3, 'Sistemas Operacionais Modernos' ) ;
INSERT INTO exemplar VALUES ( 2,9788576052371, 3, 'Portugues', 2011, 316, 'CIRCULANTE',
'Brochura', 119.65, 7, 'COMPRA', 'ATIVO', 3, 'Sistemas Operacionais Modernos' ) ;

SELECT * FROM exemplar ;

-- transforma��o em tabela
CREATE TABLE nacionalidade
( cod_pais SMALLINT PRIMARY KEY,
nome_pais VARCHAR2(35) NOT NULL) ;

INSERT INTO nacionalidade VALUES ( 1, 'BRASIL') ;
INSERT INTO nacionalidade VALUES ( 2, 'ESTADOS UNIDOS') ;
INSERT INTO nacionalidade VALUES ( 3, 'ALEMANHA') ;

ALTER TABLE editora ADD cod_pais SMALLINT ;

UPDATE editora ed SET ed.cod_pais = 
( SELECT cod_pais FROM nacionalidade
WHERE  UPPER(RTRIM(nome_pais)) LIKE '%'||UPPER(RTRIM(ed.nacionalidade_edit))||'%' ); 

SELECT * FROM editora ;
-- agora com nacionalidade
INSERT INTO editora VALUES
(4, 'Bookman', 'Avenida Paulista-Bela Vista', 552128739876, 231765342, 'bookman@bookman.com.br', 'Brasil', 1);
 
 -- emprestimo
 desc emprestimo ;
 SELECT * FROM emprestimo ;
INSERT INTO emprestimo VALUES ( emprestimo_seq.nextval, current_timestamp - INTERVAL '6' HOUR,
0 , 'PENDENTE', 3) ;
INSERT INTO emprestimo VALUES ( emprestimo_seq.nextval, current_timestamp - INTERVAL '2' HOUR,
0 , 'PENDENTE', 1) ;
INSERT INTO emprestimo VALUES ( emprestimo_seq.nextval, current_timestamp - INTERVAL '1' HOUR,
0 , 'PENDENTE', 3) ;
INSERT INTO emprestimo VALUES ( emprestimo_seq.nextval, current_timestamp,
0 , 'PENDENTE', 3) ;
INSERT INTO emprestimo VALUES ( emprestimo_seq.nextval, current_timestamp,
0 , 'PENDENTE', 5) ;

-- itens do emprestimo
desc ITENS_EMPRESTIMO ;
DELETE FROM ITENS_EMPRESTIMO ;
SELECT * FROM emprestimo ;
SELECT * FROM itens_emprestimo ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16000, 1, 9788580555332, current_timestamp + 5, null,
0, 'PENDENTE' ) ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16000, 1, 9788576052371 , current_timestamp + 1, null,
0, 'PENDENTE' ) ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16003, 1,9788576052371, current_timestamp + 7, null,
0, 'PENDENTE' ) ;


/************************
Atividade 02 :
1-	Com o comando ALTER TABLE adicione restri��es CHECK para Situa��o em Reserva : PENDENTE, VENCIDA, EMPRESTIMO  */
 SELECT * FROM User_constraints WHERE table_name = 'RESERVA'  AND constraint_type = 'C' ;
ALTER TABLE reserva ADD CONSTRAINT chk_situ_reserva CHECK (situacao_reserva IN ( 'PENDENTE', 'VENCIDA', 'EMPRESTIMO'));

desc reserva ;

/* 2-	Com o comando ALTER TABLE adicione restri��es CHECK para Situa��o em Itens da Reserva :
CANCELADA, PENDENTE, VENCIDA, EMPRESTIMO */
desc itens_reserva ;
SELECT * FROM User_constraints WHERE table_name = 'ITENS_RESERVA'  AND constraint_type = 'C' ;
ALTER TABLE itens_reserva ADD CONSTRAINT chk_situ_item_reserva CHECK (situacao_item_reserva IN ( 'PENDENTE', 'VENCIDA', 'EMPRESTIMO', 'CANCELADO'));

--3 � Popular as tabelas em amarelo: insira duas linhas em cada tabela
-- curso
desc curso ;
 SELECT * FROM User_constraints WHERE table_name = 'CURSO'  AND constraint_type = 'C' ;
INSERT INTO Curso VALUES ( 1, 'Analise e Desenvolvimento de Sistemas', 'TECNOLOGIA') ;
INSERT INTO Curso VALUES ( 2, 'Ciencia da Computacao', 'BACHARELADO') ;
INSERT INTO Curso VALUES ( 3, 'Matematica', 'LICENCIATURA') ;

-- aluno
desc aluno ;
SELECT * FROM aluno ;
-- chave estrangeira
ALTER TABLE aluno ADD CONSTRAINT Fkcursoaluno FOREIGN KEY ( cod_curso) REFERENCES curso ;
INSERT INTO aluno VALUES ( 4, 7654, current_date - 350, current_date + 1000, 1) ;
INSERT INTO aluno VALUES ( 3, 5142, current_date - 35, current_date + 1300, 2) ;
INSERT INTO aluno VALUES ( 6, 8854, current_date - 350, current_date + 1000, 3) ;
INSERT INTO aluno VALUES ( 7, 3142, current_date - 75, current_date + 1400, 3) ;

--funcionario
desc funcionario ;
INSERT INTO funcionario VALUES ( 2, 4216, 'Bibliotecario', current_date - 2000, null) ;

-- professor
desc professor ;
INSERT INTo professor VALUES ( 1, 777665, 'DOUTORADO', current_date - 2000, null) ;
INSERT INTo professor VALUES ( 5, 863121, 'DOUTORADO', current_date - 1000, null) ;
--autor
desc autor ;
INSERT INTO autor VALUES ( 2, 'Roger Pressman', 'Estados Unidos') ;
INSERT INTO autor VALUES ( 1, 'C.J. Date', 'Estados Unidos') ;

-- participacao obra
desc PARTICIPANTES_OBRA ;
INSERT INTO participantes_obra VALUES ( 9788580555332 , 2, 'PRINCIPAL') ;
INSERT INTO participantes_obra VALUES ( 9788576052371  , 1, 'PRINCIPAL') ;

-- reserva
desc RESERVA ;
SELECT * FROM professor ;
 SELECT * FROM User_constraints WHERE table_name = 'RESERVA'  AND constraint_type = 'C' ;
INSERT INTO reserva VALUES ( reserva_seq.nextval, current_timestamp, current_timestamp+7, 'PENDENTE', 1) ;
SELECT * FROM reserva ;
-- itens da reserva
desc itens_reserva ;
SELECT * FROM User_constraints WHERE table_name = 'ITENS_RESERVA'  AND constraint_type = 'C' ;
INSERT INTO itens_reserva VALUES ( 600, 9788580555332,'PENDENTE') ;  
INSERT INTO itens_reserva VALUES ( 600, 9788576052371 ,'PENDENTE') ; 

--4 � Ap�s popular as tabelas, transforme as colunas Nacionalidade em Editora e Autor em uma tabela auxiliar com C�digo e Nome do Pa�s, por exemplo : c�digo 01, nome Brasil. Estabele�a o relacionamento e atualize os dados nas tabelas de origem.
-- autor
desc autor ;
ALTER TABLE autor ADD cod_pais_autor SMALLINT ;

UPDATE autor a SET a.cod_pais_autor = 
( SELECT n.cod_pais FROM nacionalidade n
WHERE  UPPER(RTRIM(n.nome_pais)) LIKE '%'||UPPER(RTRIM(a.nacionalidade_autor))||'%' ); 

SELECT * from autor ;

ALTER TABLE autor ADD CONSTRAINT FKpais_autor FOREIGN KEY ( cod_pais_autor)
REFERENCES nacionalidade ;

ALTER TABLE autor MODIFY cod_pais_autor NOT NULL ;
ALTER TABLE autor DROP COLUMN nacionalidade_autor ;

-- agora com FK
INSERT INTO autor VALUES ( 3, 'Gilleanes Guedes', 1) ;
INSERT INTO autor VALUES ( 4, 'Ellen Siever',  2) ;
INSERT INTO autor VALUES ( 5, 'Andrew Tanenbaum', 2) ;

--5 � Fa�a o mesmo procedimento para Idioma nas tabelas Obra e Exemplar.
-- criando a nova tabela
DROP TABLE idioma CASCADE CONSTRAINTS ;
CREATE TABLE idioma 
( cod_idioma SMALLINT PRIMARY KEY,
nome_idioma VARCHAR2(20) NOT NULL) ;

INSERT INTO idioma VALUES ( 1, 'Ingles') ;
INSERT INTO idioma VALUES ( 2, 'Portugues') ;
INSERT INTO idioma VALUES ( 3, 'Alemao') ;
INSERT INTO idioma VALUES ( 4, 'Espanhol') ;
INSERT INTO idioma VALUES ( 5, 'Frances') ;
INSERT INTO idioma VALUES ( 6, 'Japones') ;

-- defininindo nova coluna em obra para receber o idioma
ALTER TABLE obra ADD cod_idioma_original SMALLINT ;

UPDATE obra o SET o.cod_idioma_original = ( SELECT i.cod_idioma
FROM idioma i
WHERE UPPER(RTRIM(o.idioma_original)) LIKE '%'||UPPER(RTRIM(i.nome_idioma))||'%');

-- transformando a nova coluna de obra em FK
ALTER TABLE obra ADD CONSTRAINT fk_idioma_obra FOREIGN KEY ( cod_idioma_original)
REFERENCES idioma ( cod_idioma) ;

ALTER TABLE obra MODIFY cod_idioma_original NOT NULL;
ALTER TABLE obra DROP COLUMN idioma_original ;

-- agora com FK para idioma
INSERT INTO obra VALUES (9788572355344, 'Introducao a Sistemas de Banco de dados', 'Computacao', 'Livro Tecnico', 'banco de dados', 2);
INSERT INTO obra VALUES (9788732052399, 'UML 2 Uma abordagem pratica', 'Computacao', 'Livro Tecnico', 'modelagem de software', 1 );
INSERT INTO obra VALUES (9788560031009, 'Linux O Guia Essencial', 'Computacao', 'Livro Tecnico', 'sistemas operacionais', 2 );

SELECT * FROM obra ;

-- transformando em exemplar
ALTER TABLE exemplar ADD cod_idioma_exemplar SMALLINT ;

UPDATE exemplar e SET e.cod_idioma_exemplar = ( SELECT i.cod_idioma
FROM idioma i
WHERE UPPER(RTRIM(e.idioma_exemplar)) LIKE '%'||UPPER(RTRIM(i.nome_idioma))||'%');

ALTER TABLE exemplar ADD CONSTRAINT fk_idioma_exemplar FOREIGN KEY ( cod_idioma_exemplar)
REFERENCES idioma(cod_idioma) ;

ALTER TABLE exemplar MODIFY cod_idioma_exemplar NOT NULL ;
ALTER TABLE exemplar DROP COLUMN idioma_exemplar ;

DESC exemplar ;
INSERT INTO exemplar VALUES ( 1, 9788572355344 , 7, 2010, 846, 'CIRCULANTE',
'Brochura', 169.65, 7, 'COMPRA', 'ATIVO', 2, 'Introduction to Database Systems', 2 ) ;
INSERT INTO exemplar VALUES ( 2, 9788572355344 , 7, 2010, 846, 'CIRCULANTE',
'Brochura', 169.65, 7, 'COMPRA', 'ATIVO', 2, 'Introduction to Database Systems', 2 ) ;
INSERT INTO exemplar VALUES ( 1,9788732052399, 2, 2014, 316, 'CIRCULANTE',
'Brochura', 129.65, 7, 'COMPRA', 'ATIVO', 3, 'UML2', 1 ) ;
INSERT INTO exemplar VALUES ( 2,9788732052399, 2, 2014, 316, 'CIRCULANTE',
'Brochura', 129.65, 7, 'COMPRA', 'ATIVO', 3, 'UML2' , 1 ) ;
INSERT INTO exemplar VALUES ( 3,9788732052399, 2, 2014, 316, 'CIRCULANTE',
'Brochura', 129.65, 7, 'COMPRA', 'ATIVO', 3, 'UML2' , 1) ;
INSERT INTO exemplar VALUES ( 1,9788560031009, 2, 2014, 316, 'CIRCULANTE',
'Brochura', 109.65, 7, 'COMPRA', 'ATIVO', 4, 'Linux Essencial', 1 ) ;
INSERT INTO exemplar VALUES ( 2,9788560031009, 2, 2014, 316, 'CIRCULANTE',
'Brochura', 109.65, 7, 'COMPRA', 'ATIVO', 4, 'Linux Essencial',1  ) ;
INSERT INTO exemplar VALUES ( 3,9788560031009, 2, 2014, 316, 'CIRCULANTE',
'Brochura', 109.65, 7, 'COMPRA', 'ATIVO', 4, 'Linux Essencial',1 ) ;

INSERT INTO ITENS_EMPRESTIMO VALUES ( 16001, 1, 9788572355344  , current_timestamp + 7, null,
0, 'PENDENTE' ) ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16001, 1,9788732052399, current_timestamp + 7, null,
0, 'PENDENTE' ) ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16001, 2,9788732052399 , current_timestamp + 5, null,
0, 'PENDENTE' ) ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16002, 3,9788732052399 , current_timestamp + 7, null,
0, 'PENDENTE' ) ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16002, 2,9788560031009 , current_timestamp + 3, null,
0, 'PENDENTE' ) ;
INSERT INTO ITENS_EMPRESTIMO VALUES ( 16003, 3,9788560031009 , current_timestamp + 7, null,
0, 'PENDENTE' ) ;

UPDATE ITENS_EMPRESTIMO SET DT_DEVOLUCAO = current_timestamp , SITUACAO_itens_emprestimo = 'DEVOLVIDO'
WHERE num_emprestimo = 16001 ;

INSERT INTO participantes_obra VALUES ( 9788732052399 , 3, 'PRINCIPAL') ;
INSERT INTO participantes_obra VALUES ( 9788560031009  , 4, 'PRINCIPAL') ;

SELECT COUNT(*) FROM exemplar ;
SELECT COUNT(*) FROM itens_emprestimo ;
SELECT COUNT(*) FROM itens_reserva ;
